package main

import (
	"html/template"
	"log"
	"net/http"
	"sort"
	"strings"
)

type WordCount struct {
	Word      string
	Paragraph string
	Count     int
}

type WordCountRes struct {
	Paragraph string
	WordArray []WordCount
	Success   bool
}

type BookWordInputs struct {
	ParagraphString string
}

func main() {
	tmpl := template.Must(template.ParseFiles("index.html"))
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			err := tmpl.Execute(w, nil)
			if err != nil {
				log.Printf("Invalid method: %v", err)
			}
			return
		}

		paragraph := BookWordInputs{
			ParagraphString: r.FormValue("paragraph"),
		}

		s := []string{paragraph.ParagraphString}
		words := strings.Split(strings.Join(s, ""), " ")

		// Count same words in s
		m := make(map[string]int)
		for _, word := range words {
			if _, ok := m[word]; ok {
				m[word]++
			} else {
				m[word] = 1
			}
		}

		// create and fill slice of word-Count pairs for sorting by Count
		wordCounts := make([]WordCount, 0, len(m))
		for key, val := range m {
			wordCounts = append(wordCounts, WordCount{Word: key, Count: val})
		}

		// sort wordCount slice by decreasing Count number
		sort.Slice(wordCounts, func(i, j int) bool {
			return wordCounts[i].Count > wordCounts[j].Count
		})

		// display the ten most frequent words
		maxRecords := 10
		if len(wordCounts) < 10 {
			maxRecords = len(wordCounts)
		}
		topTenWords := wordCounts[0:maxRecords]

		err := tmpl.Execute(w, WordCountRes{
			Success:   true,
			Paragraph: paragraph.ParagraphString,
			WordArray: topTenWords,
		})
		if err != nil {
			return
		}
	})
	err := http.ListenAndServe(":8080", nil)
	if err != nil {
		log.Printf("Something went wrong: %v", err)
	}
}
