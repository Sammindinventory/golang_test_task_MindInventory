package main

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"regexp"
	"sort"
	"strings"
)

type BookWords struct {
	Title string
	Count int
}

type BookResponse struct {
	BookWords []BookWords
	Paragraph string
}

func main() {
	var template, err = template.ParseGlob("views/*")
	if err != nil {
		panic(err.Error())
		return
	}
	http.HandleFunc("/book-words-count", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			err := template.ExecuteTemplate(w, "index", BookResponse{})
			if err != nil {
				log.Printf("Invalid method: %v", err)
			}
			return
		}

		input := r.FormValue("paragraph")
		regx, err := regexp.Compile(`[^\w]`)
		if err != nil {
			log.Fatal(err)
		}
		var finalInput = regx.ReplaceAllString(input, " ")
		var arr []BookWords
		for word, count := range bookWordsCount(finalInput) {
			obj := BookWords{Title: word, Count: count}
			arr = append(arr, obj)
		}

		//Sort array using count
		sort.SliceStable(arr, func(i, j int) bool {
			return arr[i].Count > arr[j].Count
		})

		var result = arr
		//Sort array to select top 10
		if len(arr) > 10 {
			result = arr[0:10]
		}

		var response BookResponse
		if len(result) > 0 {
			response.BookWords = result
			response.Paragraph = input
		}
		template.ExecuteTemplate(w, "index", response)
	})

	fmt.Printf("Starting server at port 8080\n")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}

func bookWordsCount(st string) map[string]int {
	input := strings.Fields(st)
	wc := make(map[string]int)
	for _, word := range input {
		if len(word) > 2 {
			_, matched := wc[word]
			if matched {
				wc[word] += 1
			} else {
				wc[word] = 1
			}
		}
	}
	return wc
}
