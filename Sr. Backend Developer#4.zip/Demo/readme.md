

Run Command

``
go run server.go
``

Run URL
http://localhost:8080/book-words-count