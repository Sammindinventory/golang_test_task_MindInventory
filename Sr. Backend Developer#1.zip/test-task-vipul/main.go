package main

import (
	"html/template"
	"log"
	"net/http"
	"sort"
	"strings"
)

type KeyValueBase struct {
	Key   string
	Value int
}

type Response struct {
	Success bool
	Data    []KeyValueBase
	Text    string
}

func main() {

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		tmpl := template.Must(template.ParseFiles("index.html"))
		if r.Method != http.MethodPost {
			err := tmpl.Execute(w, Response{
				Success: false,
			})
			if err != nil {
				log.Printf("Method not POST, getting error while return response: %v", err)
			}
			return
		}
		res := WordCountHandler(r.FormValue("text"))
		err := tmpl.Execute(w, res)
		if err != nil {
			log.Printf("Getting error while return response: %v", err)
		}
		log.Printf("Word count from text successfully and return to client.")
	})
	log.Printf("Server started on localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))

}

func WordCountHandler(text string) Response {
	log.Printf("Word count endpoint handler.")
	var symbols = []string{".", ".", ",", ":", "\"", "!", "â€œ", "â€˜", "*", "'"}
	var KeyValue []KeyValueBase

	for _, symbol := range symbols {
		text = strings.Replace(text, symbol, "", -1)
	}

	// using strings.Field Function
	input := strings.Fields(text)
	wc := make(map[string]int)
	for _, word := range input {
		word = strings.ToLower(word)
		_, matched := wc[word]
		if matched {
			wc[word] += 1
		} else {
			wc[word] = 1
		}
	}

	for k, v := range wc {
		KeyValue = append(KeyValue, KeyValueBase{k, v})
	}

	sort.Slice(KeyValue, func(i, j int) bool {
		return KeyValue[i].Value > KeyValue[j].Value
	})
	max := 10
	if len(KeyValue) < 10 {
		max = len(KeyValue)
	}
	sortedWordList := KeyValue[0:max]
	log.Printf("Word count from text successfully.")
	return Response{
		Success: true,
		Data:    sortedWordList,
		Text:    text,
	}
}
