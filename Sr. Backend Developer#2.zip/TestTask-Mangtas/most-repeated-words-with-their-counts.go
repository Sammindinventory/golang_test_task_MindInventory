package main

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"
)

type WordCount struct {
	Word  string
	Count int
}

var (
	maxWords       = 10
	skipCharacters = strings.NewReplacer(".", "", "!", "", ",", "", ":", "", "'", "", "*", "")
	wordCountMap   = make(map[string]int)
	wordCountsArr  []WordCount
)

func main() {
	fmt.Println("Welcome to the Word Count Program!")

	fmt.Println("Please enter the texts from which the program will return the most repeated words with their count\n ")
	inputReader := bufio.NewReader(os.Stdin)
	inputStr, err := inputReader.ReadString('\n')
	if err != nil {
		log.Fatalf("Getting an error while fetching an input string! Err: %v", err.Error())
		return
	}

	//main logical process
	mostUsedWordCounts := GetMostUsedWordCounts(inputStr)

	for k, v := range mostUsedWordCounts {
		fmt.Printf("%d. \"%s\" is repeats %d times\n", k+1, v.Word, v.Count)
	}

	log.Printf("INFO: Above are the most top %d words with their repeat counts\n", maxWords)
}

//GetMostUsedWordCounts it will process the input string and return the word counts with desc order of counts
func GetMostUsedWordCounts(text string) []WordCount {
	log.Println("INFO: Word repeat count process starts")

	sanitizedString := skipCharacters.Replace(strings.ToLower(text))
	sanitizedStringArr := strings.Fields(sanitizedString)

	for _, sanitizedWord := range sanitizedStringArr {
		_, exists := wordCountMap[sanitizedWord]
		if exists {
			wordCountMap[sanitizedWord]++
		} else {
			wordCountMap[sanitizedWord] = 1
		}
	}
	log.Println("INFO: Word repeat count completed")

	log.Println("INFO: Migrating a word repeat counts in a specific struct for further process")
	for word, counts := range wordCountMap {
		wordCountsArr = append(wordCountsArr, WordCount{word, counts})
	}

	log.Println("INFO: Sorting a word repeat counts struct in descending order of counts")

	SortWordCountSlice(&wordCountsArr)

	log.Println("INFO: Sorting of word repeat counts completed")

	if len(wordCountsArr) < maxWords {
		maxWords = len(wordCountsArr)
	}

	log.Println("INFO: Slicing the data with maximum value from word counts array")
	finalWordCountArr := wordCountsArr[0:maxWords]

	log.Printf("INFO: Final word counts are ready to display\n\n\n")
	return finalWordCountArr
}

//SortWordCountSlice is used to sort the WordCount array
func SortWordCountSlice(wc *[]WordCount) {
	sort.Slice(*wc, func(a, b int) bool {
		return (*wc)[a].Count > (*wc)[b].Count
	})
}